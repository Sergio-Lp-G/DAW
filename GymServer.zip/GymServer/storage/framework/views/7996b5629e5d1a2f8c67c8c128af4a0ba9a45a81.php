<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h1>Actualización de sesión <?php echo e($sesion->id); ?> </h1>

            <form action="/sesions/<?php echo e($sesion->id); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="_method" value="PUT">
                <div>
                    <label for="date">Inicio</label>
                    <input type="text" name="date" value="<?php echo e($sesion->date); ?>">
                </div>

                <div>
                    <label for="startime">Inicio</label>
                    <input type="text" name="startime" value="<?php echo e($sesion->startime); ?>">
                </div>

                <div>
                    <label for="abreviation">Abreviatura</label>
                    <input type="text" name="abreviation" value="<?php echo e($sesion->abreviation); ?>">
                </div>

                <div>
                    <input type="submit" value="actualizar">
                </div>
            </form>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/sesions/edit.blade.php ENDPATH**/ ?>