
<table class="table table-striped">
<tr>
    <th>Código</th>
    <th>Día</th>
    <th>Hora inicio</th>
    <th>Hora final</th>
    <th></th>

</tr>
 <?php $__currentLoopData = $sesions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sesion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($sesion['id']); ?> </td>
    <td><?php echo e($sesion['date']); ?> </td>
    <td><?php echo e($sesion['startime']); ?> </td>
    <td><?php echo e($sesion['endtime']); ?> </td>
    <td> <a class="btn btn-primary btn-sm" href="/sesions/<?php echo e($sesion['id']); ?>">Ver</a></td>
    
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
</table>


<?php /**PATH /var/www/html/resources/views/activities/ajax/filter.blade.php ENDPATH**/ ?>