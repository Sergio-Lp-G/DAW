<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <select id="selectActividades" name="activity" class="selectpicker" aria-label="size 5 select example">
            <?php $__empty_1 = true; $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($activity->id); ?>"><?php echo e($activity->name); ?> </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <option value="0">Nul0</option>
            <?php endif; ?>
        </select>
    </div>
    <br>
    <input type="button" id="buscarActividad" value="Buscar actividad" class="btn btn-primary float-right">

    <br>
    <br>
    <div id="destinoActividades">
        destino filtro...
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/activities/search.blade.php ENDPATH**/ ?>