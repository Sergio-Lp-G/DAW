<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">


            <h1>Reservas<br>
                <a href="/bookings/create" class="btn btn-primary float-right">
                    Nueva reserva
                </a>
                <a href="/bookings/search" class="btn btn-secondary float-right">
                    Buscar reserva
                </a>
            </h1>

            <table class="table table-striped" border="1">
                <tr>
                    <th>Reserva</th>
                    <th>Usuario</th>
                    <th>Sesion</th>
                    <th>Actividad</th>
                    <th>Fecha de actividad</th>
                    <th></th>
                    <th></th>
                </tr>
                <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($booking->id); ?> </td>
                    <td><?php echo e($booking->user_id); ?> </td>
                    <td><?php echo e($booking->ssession_id); ?> </td>
                    <td><?php echo e($booking->activity_id); ?> </td>
                    <td><?php echo e($booking->activity_id->date); ?> </td>
                    <td>...</td>
                    <td> <a class="btn btn-primary btn-sm" href="/bookings/<?php echo e($booking->id); ?>">Ver</a></td>
                    <td> <a class="btn btn-primary btn-sm" href="/bookings/<?php echo e($booking->id); ?>/edit">Editar</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3">No hay reservas registradas</td>
                </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/bookings/index.blade.php ENDPATH**/ ?>