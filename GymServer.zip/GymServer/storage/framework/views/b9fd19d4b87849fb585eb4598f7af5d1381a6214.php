<?php $__env->startSection('content'); ?>
<div class="container">


    <div class="row justify-content-center">
        <div class="col-md-8">


            <h1>Lista de usuarios
                <a href="/users/create" class="btn btn-primary float-right">
                    Nuevo
                </a>
            </h1>
            <br>
            <table class="table table-striped">
                <tr>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Rol</th>

                    <th> </th>
                    <th> </th>
                </tr>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($user->name); ?> </td>
                    <td><?php echo e($user->email); ?> </td>
                    <td><?php echo e($user->role_name); ?> </td>

                    <td> <a class="btn btn-primary btn-sm" href="/users/<?php echo e($user->id); ?>">Ver</a></td>
                    <td> <a class="btn btn-primary btn-sm" href="/users/<?php echo e($user->id); ?>/edit">Editar</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3">No hay user registrados</td>
                </tr>
                <?php endif; ?>
            </table>






        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/users/index.blade.php ENDPATH**/ ?>