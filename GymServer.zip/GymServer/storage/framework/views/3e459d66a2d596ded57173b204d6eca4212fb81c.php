<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h1>Actualización de sesión <?php echo e($user->id); ?> </h1>

            <form action="/users/<?php echo e($user->id); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="_method" value="PUT">
                <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                <div>
                    <label for="name">Nombre</label>
                    <input type="text" name="name" value="<?php echo e($user->name); ?>">
                </div>

                <div>
                    <label for="dni">DNI</label>
                    <input type="text" name="dni" value="<?php echo e($user->dni); ?>">
                </div>

                <div>
                    <label for="email">Email</label>
                    <input type="text" name="email" value="<?php echo e($user->email); ?>">
                </div>
                <hr>
                <div>
                    <label for="birthday">Fecha de nacumiento</label>
                    <input type="text" name="birthday" value="<?php echo e($user->birthday); ?>">
                </div>
                <hr>
                <div>
                    <label for="weight">Peso</label>
                    <input type="number" name="weight" value="<?php echo e($user->weight); ?>">
                </div>
                <div>
                    <label for="height">Altura</label>
                    <input type="number" name="height" value="<?php echo e($user->height); ?>">
                </div>
                <div>
                    <label for="gender">Genero</label>

                    <select name="gender" id="gender" class="selectpicker" aria-label="size 5 select example">
                        <?php echo e($selected = $user->gender); ?>

                        <option <?php echo e($selected == "hombre" ? "selected" : ''); ?> value="hombre">Hombre</option>
                        <option <?php echo e($selected == "mujer" ? "selected" : ''); ?> value="mujer">Mujer</option>
                        <option <?php echo e($selected == "otro" ? "selected" : ''); ?> value="otro">Otro</option>
                    </select>
                </div>
                <hr>
                <div>
                    <label for="password">Contraseña</label>
                    <input type="password" name="password" value="<?php echo e($user->password); ?>">
                </div>

                <div>
                    <label for="role_name">Rol</label>

                    <select name="role_name" id="role_name" class="selectpicker" aria-label="size 5 select example">
                        <?php echo e($selected = $user->role_name); ?>

                        <option <?php echo e($selected == "user" ? "selected" : ''); ?> value="user">User</option>
                        <option <?php echo e($selected == "admin" ? "selected" : ''); ?> value="admin">Admin</option>
                    </select>
                </div>

                <div>
                    <input type="submit" value="actualizar">
                </div>
            </form>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/users/edit.blade.php ENDPATH**/ ?>