<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h1>Creando una sesión</h1>
            <br>
            <form action="/sesions" method="post">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="activity">Actividad</label>

                    <select name="activity" class="selectpicker" aria-label="size 5 select example">
                        <?php $__empty_1 = true; $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($activity->id); ?>"><?php echo e($activity->name); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <option value="0">Nuleo</option>
                        <?php endif; ?>
                    </select>
                </div>
                <br>
                <div>
                    <label for="days[]">Días</label>
                    <select name="days[]" class="selectpicker" multiple aria-label="size 5 select example">
                        <option value="lunes">Lunes</option>
                        <option value="martes">Martes</option>
                        <option value="miercoles">Miercoles</option>
                        <option value="jueves">Jueves</option>
                        <option value="viernes">Viernes</option>
                    </select>
                </div>
                <br>
                <div>
                    <label for="month">Mes</label>
                    <select name="month" class="selectpicker" aria-label="size 12 select example">
                        <option value="1">Enero</option>
                        <option value="2">Febrero</option>
                        <option value="3">Marzo</option>
                        <option value="4">Abril</option>
                        <option value="5">Mayo</option>
                        <option value="6">Junio</option>
                        <option value="7">Julio</option>
                        <option value="8">Agosto</option>
                        <option value="9">Septiembre</option>
                        <option value="10">Octubre</option>
                        <option value="11">Noviembre</option>
                        <option value="12">Diciembre</option>
                    </select>
                </div>
                <br>
                
                <div>
                    <label for="startime">Inicio</label>
                    <input type="time" name="startime" id="startime">
                </div>
                <br>
                <div>
                    <label for="endtime">Fin</label>
                    <input type="time" name="endtime" id="endtime">
                </div>
                <br>
                <div>
                    <input class="btn btn-primary" type="submit" value="crear">
                </div>
            </form>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/sesions/create.blade.php ENDPATH**/ ?>