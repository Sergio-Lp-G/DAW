<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">


            <h1>Nuevo Usuario </h1>

            <form action="/users" method="post">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="name">Nombre</label>
                    <br>
                    <input type="text" name="name" id="name">
                </div>
                <br>
                <div>
                    <label for="dni">DNI</label>
                    <br>
                    <input type="text" name="dni" id="dni">
                </div>
                <br>
                <div>
                    <label for="email">Email</label>
                    <br>
                    <input type="email" name="email" id="email">
                </div>
                <br>
                <div>
                    <label for="password">Contraseña</label>
                    <br>
                    <input type="password" name="password" id="password">
                </div>
                <br>
                <div>
                    <label for="weight">Peso(kg)</label>
                    <br>
                    <input type="number" min="10" max="400" name="weight" id="weight">
                </div>
                <br>
                <div>
                    <label for="height">Altura(cm)</label>
                    <br>
                    <input type="number" min="90" max="300" name="height" id="height">
                </div>
                <br>
                <div>
                    <label for="gender">Genero</label>
                    <br>
                    <select name="gender" id="gender" class="selectpicker" aria-label="size 5 select example">
                        <option value="hombre">Hombre</option>
                        <option value="mujer">Mujer</option>
                        <option value="otro">Otro</option>
                    </select>
                </div>
                <br>
                <div>
                    <label for="birthday">Fecha de nacimiento</label>
                    <br>
                    <input type="date" name="birthday" id="birthday">
                </div>
                <br>
                <div>
                    <label for="role_name">Rol</label>
                    <br>
                    <select name="role_name" id="role_name" class="selectpicker" aria-label="size 5 select example">
                        <option value="user">Usuario</option>
                        <option value="admin">Administrador</option>
                    </select>
                </div>
                <br>
                <div>
                    <input type="submit" value="crear">
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/users/create.blade.php ENDPATH**/ ?>