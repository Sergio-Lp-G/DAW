<?php $__env->startSection('content'); ?>
<div class="container">

    <h1>Usuario <?php echo e($user->name); ?></h1>

    <ul>
        <li>
            <strong>Nombre</strong>
            <?php echo e($user->name); ?>

        </li>
        <li>
            <strong>Dni</strong>
            <?php echo e($user->dni); ?>

        </li>
        <li>
            <strong>Email</strong>
            <?php echo e($user->email); ?>

        </li>
        <li>
            <strong>Peso</strong>
            <?php echo e($user->weight); ?> kg
        </li>
        <li>
            <strong>Altura</strong>
            <?php echo e($user->height); ?> cm
        </li>
        <li>
            <strong>Cumpleaños</strong>
            <?php echo e($user->birthday); ?>

        </li>
        <li>
            <strong>Genero</strong>
            <?php echo e($user->gender); ?>

        </li>
        <li>
            <strong>Rol</strong>
            <?php echo e($user->role_name); ?>

        </li>
    </ul>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/users/show.blade.php ENDPATH**/ ?>