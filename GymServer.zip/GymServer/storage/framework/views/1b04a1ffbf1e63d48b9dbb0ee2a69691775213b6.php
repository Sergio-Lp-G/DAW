<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h1>Lista de sesiones.<br></h1>

            <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->role_name == 'admin' ): ?>
            <input type="button" class="btn btn-primary" value="Crear" onclick="location.href='/sesions/create'">
            <br><br>
            <?php endif; ?>
            <?php endif; ?>
            <table class="table table-striped" border="1">
                <tr>
                    <th>Fecha</th>
                    <th>Inicio</th>
                    <th>Fin</th>
                    <th>Actividad Id</th>
                    
                    <th></th>
                    
                </tr>
                <?php $__empty_1 = true; $__currentLoopData = $sesions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sesion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($sesion->date); ?> </td>
                    <td><?php echo e($sesion->startime); ?> </td>
                    <td><?php echo e($sesion->endtime); ?> </td>
                    <td><?php echo e($sesion->activity_id); ?> </td>
                    
                    <td> <a class="btn btn-primary btn-sm" href="/sesions/<?php echo e($sesion->id); ?>">Ver</a></td>
                    

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3">No hay actividades registradas</td>
                </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/sesions/index.blade.php ENDPATH**/ ?>