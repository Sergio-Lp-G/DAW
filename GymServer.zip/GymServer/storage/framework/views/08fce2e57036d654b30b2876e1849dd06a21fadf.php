<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Actividad nº <?php echo e($activity->id); ?></h1>

    <ul>
        <li>
            <strong>Código</strong>
            <?php echo e($activity->id); ?>

        </li>
        <li>
            <strong>Nombre</strong>
            <?php echo e($activity->name); ?>

        </li>
        <li>
            <strong>Descripción</strong>
            <?php echo e($activity->description); ?>

        </li>
        <li>
            <strong>Duración</strong>
            <?php echo e($activity->duration); ?>

        </li>
        <li>
            <strong>Participantes</strong>
            <?php echo e($activity->participants); ?>

        </li>
    </ul>
    <br>
    <hr>
    <h2>Sesiones:</h2>
    <form method="POST" id="formulario">
        <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
        <input type="hidden" id="sesions" value="<?php echo e($activity->sesions); ?>">

    </form>

    <input type="button" id="buscarSesiones" value="Buscar sesiones"  class="btn btn-primary float-right">

    <br>
    <div id="destinofiltro">
        destino filtro...
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/activities/show.blade.php ENDPATH**/ ?>