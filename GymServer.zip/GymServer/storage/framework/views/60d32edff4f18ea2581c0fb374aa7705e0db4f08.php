
<table class="table table-striped">
    <tr>
        <th>Nombre</th>
        <th>Descripción</th>
        <th>Duración</th>
        <th>Max. Participantes</th>
        <th></th>
        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->role_name == 'admin' ): ?>
                <th></th>

            <?php endif; ?>

        <?php endif; ?>
    </tr>
    <tr>
        <td><?php echo e($actividad['name']); ?> </td>
        <td><?php echo e($actividad['description']); ?> </td>
        <td><?php echo e($actividad['duration']); ?> </td>
        <td><?php echo e($actividad['participants']); ?> </td>
        <td> <a class="btn btn-primary btn-sm" href="/activities/<?php echo e($actividad['id']); ?>">Ver</a></td>
        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->role_name == 'admin' ): ?>
            <td> <a class="btn btn-primary btn-sm" href="/activities/<?php echo e($actividad['id']); ?>/edit">Editar</a></td>
            <?php endif; ?>

        <?php endif; ?>
    </tr>
</table><?php /**PATH /var/www/html/resources/views/activities/ajax/searchactividades.blade.php ENDPATH**/ ?>