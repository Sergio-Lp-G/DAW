<?php $__env->startSection('content'); ?>
<div class="container">


    <div class="row justify-content-center">
        <div class="col-md-8">


            <h1>Lista de actividades.<br>
                <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->role_name == 'admin' ): ?>
                <a href="/activities/create" class="btn btn-primary float-right">
                    Nueva actividad
                </a>
                <?php endif; ?>

                <?php endif; ?>

                <a href="/activities/search" class="btn btn-secondary float-right">
                    Buscar actividades
                </a>
            </h1>

            <table class="table table-striped" border="1">
                <tr>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Duración</th>
                    <th>MaxParticipantes</th>
                    <th>Sesiones</th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                </tr>
                <?php $__empty_1 = true; $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($activity->name); ?> </td>
                    <td><?php echo e($activity->description); ?> </td>
                    <td><?php echo e($activity->duration); ?> </td>
                    <td><?php echo e($activity->participants); ?> </td>
                    <td>...</td>
                    <td> <a class="btn btn-primary btn-sm" href="/activities/<?php echo e($activity->id); ?>">Ver</a></td>

                    <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->role_name == 'admin' ): ?>
                    <td> <a class="btn btn-primary btn-sm" href="/activities/<?php echo e($activity->id); ?>/edit">Editar</a></td>
                    <td>
                        <form action="/activities/<?php echo e($activity->id); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="_method" value="DELETE">
                            <input class="btn btn-primary btn-sm" type="submit" value="Borrar">
                        </form>
                    </td>

                    <?php endif; ?>
                    <td> </td>
                    <td> </td>
                    <?php endif; ?>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3">No hay actividades registradas</td>
                </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/activities/index.blade.php ENDPATH**/ ?>