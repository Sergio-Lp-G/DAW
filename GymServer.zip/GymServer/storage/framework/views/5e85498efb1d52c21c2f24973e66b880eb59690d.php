<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h1>Actualización de sesión <?php echo e($activity->id); ?> </h1>

            <form action="/activities/<?php echo e($activity->id); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="_method" value="PUT">
                <input type="hidden" name="id" value="<?php echo e($activity->id); ?>">
                <div>
                    <label for="name">Nombre</label>
                    <input type="text" name="name" value="<?php echo e($activity->name); ?>">
                </div>

                <div>
                    <label for="description">Descripción</label>
                    <input type="text" name="description" value="<?php echo e($activity->description); ?>">
                </div>

                <div>
                    <label for="duration">Duracion</label>
                    <input type="text" name="duration" value="<?php echo e($activity->duration); ?>">
                </div>
                <div>
                    <label for="participants">Participantes</label>
                    <input type="text" name="participants" value="<?php echo e($activity->participants); ?>">
                </div>

                <div>
                    <input type="submit" value="actualizar">
                </div>
            </form>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/activities/edit.blade.php ENDPATH**/ ?>