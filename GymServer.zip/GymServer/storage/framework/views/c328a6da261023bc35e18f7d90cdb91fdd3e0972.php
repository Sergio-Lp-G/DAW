<?php $__env->startSection('content'); ?>
<div class="container">

    <h1>Sesion nº <?php echo e($sesion->id); ?></h1>

    <ul>
        <li>
            <strong>Código</strong>
            <?php echo e($sesion->id); ?>

        </li>
        <li>
            <strong>Inicio</strong>
            <?php echo e($sesion->startime); ?>

        </li>
        <li>
            <strong>Fin</strong>
            <?php echo e($sesion->endtime); ?>

        </li>
        <li>
            <strong>Actividad</strong>
            <?php echo e($activity->name); ?>

        </li>
    </ul>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/sesions/show.blade.php ENDPATH**/ ?>