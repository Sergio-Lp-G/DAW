console.log("enlazado");

$('#formulario').on("click",function (e) {
  e.preventDefault();
  console.log("ha hecho click");
  data = $('#filtro').val();
  console.log(data);
  alert(data);
  $.get("/studies/filter?filter=" + data, function (data, status) {
    console.log("Data: " + data + "\nStatus: " + status);
    console.log(data);
    $('#destinofiltro').html(data);
  });
  alert("datos recibidos");
})



function grabar(dataJ) {
  //recorrer el dataJ y grabar en una tabla html dentro de index.div#destinofiltro

}