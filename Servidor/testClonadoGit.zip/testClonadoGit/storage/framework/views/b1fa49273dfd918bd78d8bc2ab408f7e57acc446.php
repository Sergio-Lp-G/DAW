<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Estudio nº <?php echo e($study); ?></h1>


    <ul>
        <li>
            <strong>Código</strong>
            <?php echo e($study->code); ?>

        </li>
        <li>
            <strong>Nombre</strong>
            <?php echo e($study->name); ?>

        </li>
        <li>
            <strong>Abreviatura</strong>
            <?php echo e($study->abreviation); ?>

        </li>
    </ul>
</body>
</html><?php /**PATH /var/www/html/resources/views/study/show.blade.php ENDPATH**/ ?>