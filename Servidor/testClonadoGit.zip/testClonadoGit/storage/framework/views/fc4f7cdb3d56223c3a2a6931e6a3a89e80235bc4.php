<?php $__env->startSection('content'); ?>




<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">


            <h1>Lista de estudios
                <a href="/studies/create" class="btn btn-primary float-right">
                    Nuevo
                </a>
            </h1>

            <table class="table table-striped" border="1">
                <tr>
                    <th>Código</th>
                    <th>Nombre</th>
                    <th>Abreviatura</th>
                </tr>
                <?php $__empty_1 = true; $__currentLoopData = $studies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $study): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($study->code); ?> </td>
                    <td><?php echo e($study->name); ?> </td>
                    <td><?php echo e($study->abreviation); ?> </td>
                    <td> <a class="btn btn-primary btn-sm" href="/studies/<?php echo e($study->id); ?>">Ver</a></td>
                    <td> <a class="btn btn-primary btn-sm" href="/studies/<?php echo e($study->id); ?>/edit">Editar</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3">No hay estudios registrados</td>
                </tr>
                <?php endif; ?>
            </table>

            <hr>
            <h2>Busqueda ajax</h2>
            <form action="" id="formulario">
                <input type="text" id="filtro">
                <input type="submit" id="buscar">
            </form>
            <br>

            <div id="destinofiltro">
                destino filtro...
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="/js/ejemploajax.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/study/index.blade.php ENDPATH**/ ?>