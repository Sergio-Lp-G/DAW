<table class="table table-striped">
<tr>
    <th>Código</th>
    <th>Nombre</th>
    <th>Abreviatura</th>
</tr>
<?php $__empty_1 = true; $__currentLoopData = $studies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $study): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
    <td><?php echo e($study->code); ?> </td>
    <td><?php echo e($study->name); ?> </td>
    <td><?php echo e($study->abreviation); ?> </td>
    <td> <a class="btn btn-primary btn-sm" href="/studies/<?php echo e($study->id); ?>">Ver</a></td>
    <td> <a class="btn btn-primary btn-sm" href="/studies/<?php echo e($study->id); ?>/edit">Editar</a></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr>
    <td colspan="3">No hay estudios registrados</td>
</tr>
<?php endif; ?>
</table>
<?php /**PATH /var/www/html/resources/views/study/ajax/filter.blade.php ENDPATH**/ ?>