<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PruebaController extends Controller
{
    public function hola(){
        return 'Hola gente';
    }
    public function holanombre($name){
        return "Hola $name";
    }
}
