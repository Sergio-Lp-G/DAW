<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PruebaController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\StudyController;
use App\Http\Controllers\UserController;
use App\Models\Role;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    //return "hola mundo";

    return view('welcome');
});

Route::get('prueba',function(){
    return "estamos en pruebas";
});

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/studies/filter',[StudyController::class,'filter']);
Route::get('prueba2',[PruebaController::class, 'hola']);
Route::get('prueba2/{name}',[PruebaController::class, 'holanombre']);
Route::get('prueba3',function(){
    return "Has accedido correctamente a esta ruta";
})->middleware('role');

Route::resource('studies',StudyController::class)->middleware('auth');
Route::resource('studies',StudyController::class);
Route::resource('users',UserController::class);
Route::resource('roles',RoleController::class);



Auth::routes();